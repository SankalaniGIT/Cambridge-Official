CREATE VIEW galleryproject AS
  SELECT `galleryinfo`.`category` AS `category`
  FROM `cambridgecollege`.`galleryinfo`
  WHERE (`galleryinfo`.`category` LIKE 'PROJECT_%');
