CREATE VIEW galleryinfo AS
  SELECT DISTINCT `c`.`category` AS `category`
  FROM (`cambridgecollege`.`category` `c`
    JOIN `cambridgecollege`.`gallery` `g`)
  WHERE (`c`.`category` = `g`.`category`);
