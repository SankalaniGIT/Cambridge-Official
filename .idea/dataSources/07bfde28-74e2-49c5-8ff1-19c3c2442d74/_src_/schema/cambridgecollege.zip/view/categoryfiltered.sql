CREATE VIEW categoryfiltered AS
  SELECT `categoryall`.`category` AS `category`
  FROM `cambridgecollege`.`categoryall`
  WHERE (NOT ((`categoryall`.`category` LIKE 'PROJECT_%')));
