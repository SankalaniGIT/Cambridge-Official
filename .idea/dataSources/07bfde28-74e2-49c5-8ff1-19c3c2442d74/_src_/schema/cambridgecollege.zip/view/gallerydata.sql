CREATE VIEW gallerydata AS
  SELECT `galleryinfo`.`category` AS `category`
  FROM `cambridgecollege`.`galleryinfo`
  WHERE (NOT ((`galleryinfo`.`category` LIKE 'PROJECT_%')));
