CREATE VIEW categoryall AS
  SELECT
    `c`.`id`       AS `id`,
    `c`.`category` AS `category`
  FROM (`cambridgecollege`.`category` `c`
    JOIN `cambridgecollege`.`categorygroup` `cg`)
  WHERE ((`cg`.`id` = '4') AND (`c`.`group_id` = `cg`.`id`));
